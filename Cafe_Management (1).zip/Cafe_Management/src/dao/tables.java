/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class tables {
    public static void main(String[] args)
    {
    try{
     
        String userTable = "Create table user(id int AUTO_INCREMENT primary key,name varchar(200), email varchar(200),Mobile_Number(11),status varchar(200),address varchar(200),Password varchar(200),),UNIQUE (email)" ;
        DbOperations.setDataOrDelete(userTable,"User Table Created Successfully."); 
    }
    catch(Exception e)
    {
     JOptionPane.showMessageDialog(null,e);
    
    }
    }
}
